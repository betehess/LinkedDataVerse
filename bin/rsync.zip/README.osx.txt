WAIT, WHERE'S THE BINARIES?!
----------------------------

Mac OSX comes with everything we need, so the package downloaded from the server is purposefully empty.